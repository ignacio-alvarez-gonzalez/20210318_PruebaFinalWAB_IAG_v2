define({
  "_widgetLabel": "Contrôleur de fléchette"
});