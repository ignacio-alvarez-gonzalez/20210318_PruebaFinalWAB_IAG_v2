define({
  "_widgetLabel": "Kontrolnik Puščice"
});