define({
  "_widgetLabel": "Στοχείο ελέγχου του Dart"
});