define({
  "_widgetLabel": "飞镖控制器"
});