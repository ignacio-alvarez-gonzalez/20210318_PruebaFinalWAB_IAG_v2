define({
  "_widgetLabel": "Kontroler Dart"
});