define({
  "_widgetLabel": "Kontroler strelice"
});