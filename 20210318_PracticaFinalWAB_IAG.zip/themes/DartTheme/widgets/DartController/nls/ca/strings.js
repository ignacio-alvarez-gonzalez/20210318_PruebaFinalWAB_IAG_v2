define({
  "_widgetLabel": "Controlador de dards"
});