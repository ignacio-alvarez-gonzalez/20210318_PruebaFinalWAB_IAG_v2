define({
  "_widgetLabel": "Pengontrol Dart"
});