define({
  "_widgetLabel": "ダート コントローラー"
});