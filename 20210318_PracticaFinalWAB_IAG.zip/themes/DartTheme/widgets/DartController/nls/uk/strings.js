define({
  "_widgetLabel": "Контролер Dart"
});