define({
  "_widgetLabel": "Kontroler Rzutki"
});