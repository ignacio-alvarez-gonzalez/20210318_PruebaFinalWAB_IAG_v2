define({
  "_widgetLabel": "Controler săgeţi"
});