define({
  "_themeLabel": "Тема Дротика",
  "_layout_default": "Компоновка по умолчанию"
});