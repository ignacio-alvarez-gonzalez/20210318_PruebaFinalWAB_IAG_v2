define({
  "_themeLabel": "Tema Dardo",
  "_layout_default": "Layout predefinido"
});