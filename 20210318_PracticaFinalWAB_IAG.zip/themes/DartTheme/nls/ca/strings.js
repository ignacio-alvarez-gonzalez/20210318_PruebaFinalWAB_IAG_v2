define({
  "_themeLabel": "Tema Dards",
  "_layout_default": "Disseny per defecte"
});