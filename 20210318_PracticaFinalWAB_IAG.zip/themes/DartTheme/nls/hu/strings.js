define({
  "_themeLabel": "Dart téma",
  "_layout_default": "Alapértelmezett elrendezés"
});