define({
  "_themeLabel": "Tema strelice",
  "_layout_default": "Zadani izgled"
});