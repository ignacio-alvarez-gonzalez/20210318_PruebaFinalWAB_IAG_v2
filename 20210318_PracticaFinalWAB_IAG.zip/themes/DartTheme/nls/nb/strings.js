define({
  "_themeLabel": "Dart-tema",
  "_layout_default": "Standardoppsett"
});