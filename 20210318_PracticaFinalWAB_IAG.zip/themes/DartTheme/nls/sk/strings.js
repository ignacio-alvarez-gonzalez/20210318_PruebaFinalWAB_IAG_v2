define({
  "_themeLabel": "Motív Dart",
  "_layout_default": "Predvolené rozloženie"
});